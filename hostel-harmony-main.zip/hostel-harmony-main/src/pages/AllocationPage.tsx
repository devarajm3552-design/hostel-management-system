import { useState } from "react";
import { mockStudents, mockRooms } from "@/data/mockData";
import { Student, Room } from "@/types/hostel";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const AllocationPage = () => {
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [rooms, setRooms] = useState<Room[]>(mockRooms);
  const [selectedStudent, setSelectedStudent] = useState("");
  const [selectedRoom, setSelectedRoom] = useState("");

  const unassigned = students.filter((s) => !s.roomId);
  const availableRooms = rooms.filter((r) => r.status === "available" && r.occupants < r.capacity);

  const handleAllocate = () => {
    if (!selectedStudent || !selectedRoom) { toast.error("Select both student and room"); return; }
    setStudents(students.map((s) => s.id === selectedStudent ? { ...s, roomId: selectedRoom } : s));
    setRooms(rooms.map((r) => r.id === selectedRoom ? { ...r, occupants: r.occupants + 1, status: r.occupants + 1 >= r.capacity ? "occupied" : "available" } : r));
    setSelectedStudent("");
    setSelectedRoom("");
    toast.success("Room allocated successfully");
  };

  const handleDeallocate = (studentId: string, roomId: string) => {
    setStudents(students.map((s) => s.id === studentId ? { ...s, roomId: null } : s));
    setRooms(rooms.map((r) => r.id === roomId ? { ...r, occupants: Math.max(0, r.occupants - 1), status: "available" } : r));
    toast.success("Student removed from room");
  };

  const assigned = students.filter((s) => s.roomId);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Room Allocation</h1>
        <p className="text-sm text-muted-foreground mt-1">Assign rooms to students</p>
      </div>

      <div className="rounded-lg border border-border bg-card p-5 space-y-4">
        <h3 className="font-semibold text-foreground">Allocate Room</h3>
        <div className="flex flex-wrap gap-4 items-end">
          <div className="min-w-[200px]">
            <p className="text-sm text-muted-foreground mb-1.5">Student</p>
            <Select value={selectedStudent} onValueChange={setSelectedStudent}>
              <SelectTrigger><SelectValue placeholder="Select student" /></SelectTrigger>
              <SelectContent>
                {unassigned.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="min-w-[200px]">
            <p className="text-sm text-muted-foreground mb-1.5">Room</p>
            <Select value={selectedRoom} onValueChange={setSelectedRoom}>
              <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
              <SelectContent>
                {availableRooms.map((r) => <SelectItem key={r.id} value={r.id}>Room {r.number} ({r.occupants}/{r.capacity})</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleAllocate}>Allocate</Button>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <h3 className="font-semibold text-foreground p-4 border-b border-border">Current Allocations</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Student</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Room</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {assigned.map((s) => {
              const room = rooms.find((r) => r.id === s.roomId);
              return (
                <tr key={s.id} className="border-b border-border last:border-0">
                  <td className="p-3 font-medium text-foreground">{s.name}</td>
                  <td className="p-3 text-muted-foreground">Room {room?.number} (Floor {room?.floor})</td>
                  <td className="p-3">
                    <Button variant="outline" size="sm" onClick={() => handleDeallocate(s.id, s.roomId!)}>
                      Deallocate
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AllocationPage;
