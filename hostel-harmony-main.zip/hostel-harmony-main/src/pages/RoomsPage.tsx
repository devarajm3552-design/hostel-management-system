import { useState } from "react";
import { mockRooms } from "@/data/mockData";
import { Room } from "@/types/hostel";
import { Plus, DoorOpen, Wrench } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const statusBadge = {
  available: "bg-success/10 text-success",
  occupied: "bg-accent/10 text-accent",
  maintenance: "bg-warning/10 text-warning",
};

const RoomsPage = () => {
  const [rooms, setRooms] = useState<Room[]>(mockRooms);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ number: "", floor: "1", capacity: "1", type: "single" as Room["type"] });

  const handleAdd = () => {
    if (!form.number.trim()) { toast.error("Room number is required"); return; }
    const newRoom: Room = {
      id: `r${Date.now()}`,
      number: form.number,
      floor: parseInt(form.floor),
      capacity: parseInt(form.capacity),
      occupants: 0,
      type: form.type,
      status: "available",
    };
    setRooms([...rooms, newRoom]);
    setForm({ number: "", floor: "1", capacity: "1", type: "single" });
    setOpen(false);
    toast.success("Room added successfully");
  };

  const toggleMaintenance = (id: string) => {
    setRooms(rooms.map((r) => r.id === id ? { ...r, status: r.status === "maintenance" ? "available" : "maintenance" } : r));
  };

  const deleteRoom = (id: string) => {
    setRooms(rooms.filter((r) => r.id !== id));
    toast.success("Room deleted");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Rooms</h1>
          <p className="text-sm text-muted-foreground mt-1">{rooms.length} total rooms</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-2" />Add Room</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add New Room</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-2">
              <div><Label>Room Number</Label><Input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} maxLength={10} /></div>
              <div><Label>Floor</Label><Input type="number" value={form.floor} onChange={(e) => setForm({ ...form, floor: e.target.value })} min={1} max={20} /></div>
              <div><Label>Capacity</Label><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} min={1} max={6} /></div>
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as Room["type"] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single</SelectItem>
                    <SelectItem value="double">Double</SelectItem>
                    <SelectItem value="triple">Triple</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleAdd} className="w-full">Add Room</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {rooms.map((room) => (
          <div key={room.id} className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <DoorOpen className="h-5 w-5 text-primary" />
                <span className="font-semibold text-foreground">Room {room.number}</span>
              </div>
              <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${statusBadge[room.status]}`}>
                {room.status}
              </span>
            </div>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Floor: {room.floor} · Type: {room.type}</p>
              <p>Occupancy: {room.occupants}/{room.capacity}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => toggleMaintenance(room.id)}>
                <Wrench className="h-3 w-3 mr-1" />
                {room.status === "maintenance" ? "Restore" : "Maintenance"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => deleteRoom(room.id)} className="text-destructive hover:text-destructive">
                Delete
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoomsPage;
