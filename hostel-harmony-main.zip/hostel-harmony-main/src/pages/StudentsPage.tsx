import { useState } from "react";
import { mockStudents } from "@/data/mockData";
import { Student } from "@/types/hostel";
import { Plus, Search, Mail, Phone } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const StudentsPage = () => {
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", course: "" });

  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.course.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = () => {
    if (!form.name.trim() || !form.email.trim()) {
      toast.error("Name and email are required");
      return;
    }
    const newStudent: Student = {
      id: `s${Date.now()}`,
      ...form,
      roomId: null,
      registeredAt: new Date().toISOString().split("T")[0],
      feesPaid: 0,
      totalFees: 60000,
    };
    setStudents([...students, newStudent]);
    setForm({ name: "", email: "", phone: "", address: "", course: "" });
    setOpen(false);
    toast.success("Student registered successfully");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Students</h1>
          <p className="text-sm text-muted-foreground mt-1">{students.length} registered students</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-2" />Add Student</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Register New Student</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-2">
              {(["name", "email", "phone", "address", "course"] as const).map((field) => (
                <div key={field}>
                  <Label className="capitalize">{field}</Label>
                  <Input
                    value={form[field]}
                    onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                    placeholder={`Enter ${field}`}
                    maxLength={field === "phone" ? 15 : 100}
                  />
                </div>
              ))}
              <Button onClick={handleAdd} className="w-full">Register Student</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-10"
          placeholder="Search by name or course..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          maxLength={100}
        />
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Name</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Contact</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Course</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Room</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Fees</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => (
              <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                <td className="p-3 font-medium text-foreground">{s.name}</td>
                <td className="p-3">
                  <div className="flex flex-col gap-0.5 text-muted-foreground">
                    <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{s.email}</span>
                    <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{s.phone}</span>
                  </div>
                </td>
                <td className="p-3 text-muted-foreground">{s.course}</td>
                <td className="p-3">
                  {s.roomId ? (
                    <span className="px-2 py-1 rounded text-xs font-medium bg-success/10 text-success">Assigned</span>
                  ) : (
                    <span className="px-2 py-1 rounded text-xs font-medium bg-warning/10 text-warning">Unassigned</span>
                  )}
                </td>
                <td className="p-3 text-muted-foreground">
                  ₹{s.feesPaid.toLocaleString()} / ₹{s.totalFees.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentsPage;
