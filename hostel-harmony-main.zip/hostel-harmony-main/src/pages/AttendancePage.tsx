import { useState } from "react";
import { mockAttendance, mockStudents } from "@/data/mockData";
import { AttendanceRecord } from "@/types/hostel";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const AttendancePage = () => {
  const [records, setRecords] = useState<AttendanceRecord[]>(mockAttendance);
  const today = new Date().toISOString().split("T")[0];

  const studentsWithRoom = mockStudents.filter((s) => s.roomId);
  const todayRecords = records.filter((r) => r.date === today);
  const presentCount = todayRecords.filter((r) => r.status === "present").length;

  const toggleAttendance = (studentId: string, studentName: string) => {
    const existing = records.find((r) => r.studentId === studentId && r.date === today);
    if (existing) {
      setRecords(records.map((r) =>
        r.id === existing.id ? { ...r, status: r.status === "present" ? "absent" : "present" } : r
      ));
    } else {
      setRecords([...records, { id: `a${Date.now()}`, studentId, studentName, date: today, status: "present" }]);
    }
  };

  const markAll = (status: "present" | "absent") => {
    const newRecords = studentsWithRoom.map((s) => ({
      id: `a${Date.now()}-${s.id}`,
      studentId: s.id,
      studentName: s.name,
      date: today,
      status,
    }));
    setRecords([...records.filter((r) => r.date !== today), ...newRecords]);
    toast.success(`All marked ${status}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Attendance</h1>
          <p className="text-sm text-muted-foreground mt-1">Today: {today} · Present: {presentCount}/{studentsWithRoom.length}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => markAll("present")}>Mark All Present</Button>
          <Button variant="outline" onClick={() => markAll("absent")}>Mark All Absent</Button>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Student</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Action</th>
            </tr>
          </thead>
          <tbody>
            {studentsWithRoom.map((s) => {
              const record = records.find((r) => r.studentId === s.id && r.date === today);
              const status = record?.status;
              return (
                <tr key={s.id} className="border-b border-border last:border-0">
                  <td className="p-3 font-medium text-foreground">{s.name}</td>
                  <td className="p-3">
                    {status === "present" ? (
                      <span className="px-2 py-1 rounded text-xs font-medium bg-success/10 text-success">Present</span>
                    ) : status === "absent" ? (
                      <span className="px-2 py-1 rounded text-xs font-medium bg-destructive/10 text-destructive">Absent</span>
                    ) : (
                      <span className="px-2 py-1 rounded text-xs font-medium bg-muted text-muted-foreground">Not Marked</span>
                    )}
                  </td>
                  <td className="p-3">
                    <Button variant="outline" size="sm" onClick={() => toggleAttendance(s.id, s.name)}>
                      {status === "present" ? "Mark Absent" : "Mark Present"}
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AttendancePage;
