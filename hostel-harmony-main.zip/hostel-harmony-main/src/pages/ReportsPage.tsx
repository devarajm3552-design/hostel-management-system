import { mockStudents, mockRooms, mockFees } from "@/data/mockData";
import { FileBarChart, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const ReportsPage = () => {
  const generateCSV = (title: string, headers: string[], rows: string[][]) => {
    const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`${title} report downloaded`);
  };

  const reports = [
    {
      title: "Student Report",
      description: "List of all registered students with details",
      generate: () =>
        generateCSV("students", ["Name", "Email", "Phone", "Course", "Room"], mockStudents.map((s) => [s.name, s.email, s.phone, s.course, s.roomId || "Unassigned"])),
    },
    {
      title: "Room Allocation Report",
      description: "Room occupancy and allocation details",
      generate: () =>
        generateCSV("room_allocation", ["Room", "Floor", "Type", "Capacity", "Occupants", "Status"], mockRooms.map((r) => [r.number, String(r.floor), r.type, String(r.capacity), String(r.occupants), r.status])),
    },
    {
      title: "Fee Payment Report",
      description: "Fee collection and pending payments",
      generate: () =>
        generateCSV("fee_payments", ["Student", "Amount", "Due Date", "Status", "Paid Date"], mockFees.map((f) => [f.studentName, String(f.amount), f.dueDate, f.status, f.paidDate || "N/A"])),
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">Generate and download reports</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reports.map((report) => (
          <div key={report.title} className="rounded-lg border border-border bg-card p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-primary/10">
                <FileBarChart className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{report.title}</h3>
                <p className="text-xs text-muted-foreground">{report.description}</p>
              </div>
            </div>
            <Button variant="outline" className="w-full" onClick={report.generate}>
              <Download className="h-4 w-4 mr-2" />Download CSV
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReportsPage;
