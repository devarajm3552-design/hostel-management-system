import { useState } from "react";
import { mockComplaints } from "@/data/mockData";
import { Complaint } from "@/types/hostel";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const statusBadge = {
  pending: "bg-warning/10 text-warning",
  "in-progress": "bg-accent/10 text-accent",
  resolved: "bg-success/10 text-success",
};

const ComplaintsPage = () => {
  const [complaints, setComplaints] = useState<Complaint[]>(mockComplaints);

  const updateStatus = (id: string, status: Complaint["status"]) => {
    setComplaints(complaints.map((c) =>
      c.id === id ? { ...c, status, resolvedAt: status === "resolved" ? new Date().toISOString().split("T")[0] : null } : c
    ));
    toast.success(`Complaint marked as ${status}`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Complaints</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage student complaints</p>
      </div>

      <div className="space-y-4">
        {complaints.map((c) => (
          <div key={c.id} className="rounded-lg border border-border bg-card p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-foreground">{c.subject}</h3>
                <p className="text-sm text-muted-foreground mt-1">{c.description}</p>
                <p className="text-xs text-muted-foreground mt-2">By {c.studentName} · {c.createdAt}</p>
              </div>
              <span className={`px-2 py-1 rounded text-xs font-medium capitalize whitespace-nowrap ${statusBadge[c.status]}`}>
                {c.status}
              </span>
            </div>
            {c.status !== "resolved" && (
              <div className="flex gap-2">
                <Select value={c.status} onValueChange={(v) => updateStatus(c.id, v as Complaint["status"])}>
                  <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ComplaintsPage;
