import { Student, Room, Complaint, FeeRecord, AttendanceRecord } from "@/types/hostel";

export const mockStudents: Student[] = [
  { id: "s1", name: "Aarav Sharma", email: "aarav@email.com", phone: "9876543210", address: "Delhi", course: "B.Tech CSE", roomId: "r1", registeredAt: "2025-08-15", feesPaid: 50000, totalFees: 60000 },
  { id: "s2", name: "Priya Patel", email: "priya@email.com", phone: "9876543211", address: "Mumbai", course: "B.Tech ECE", roomId: "r2", registeredAt: "2025-08-16", feesPaid: 60000, totalFees: 60000 },
  { id: "s3", name: "Rohan Gupta", email: "rohan@email.com", phone: "9876543212", address: "Bangalore", course: "BBA", roomId: "r3", registeredAt: "2025-09-01", feesPaid: 0, totalFees: 55000 },
  { id: "s4", name: "Sneha Reddy", email: "sneha@email.com", phone: "9876543213", address: "Hyderabad", course: "B.Tech IT", roomId: null, registeredAt: "2025-09-10", feesPaid: 30000, totalFees: 60000 },
  { id: "s5", name: "Vikram Singh", email: "vikram@email.com", phone: "9876543214", address: "Jaipur", course: "B.Tech ME", roomId: "r4", registeredAt: "2025-08-20", feesPaid: 60000, totalFees: 60000 },
  { id: "s6", name: "Ananya Nair", email: "ananya@email.com", phone: "9876543215", address: "Chennai", course: "B.Sc Physics", roomId: null, registeredAt: "2025-09-15", feesPaid: 20000, totalFees: 50000 },
];

export const mockRooms: Room[] = [
  { id: "r1", number: "101", floor: 1, capacity: 2, occupants: 1, type: "double", status: "available" },
  { id: "r2", number: "102", floor: 1, capacity: 1, occupants: 1, type: "single", status: "occupied" },
  { id: "r3", number: "103", floor: 1, capacity: 3, occupants: 2, type: "triple", status: "available" },
  { id: "r4", number: "201", floor: 2, capacity: 2, occupants: 2, type: "double", status: "occupied" },
  { id: "r5", number: "202", floor: 2, capacity: 1, occupants: 0, type: "single", status: "available" },
  { id: "r6", number: "203", floor: 2, capacity: 2, occupants: 0, type: "double", status: "maintenance" },
  { id: "r7", number: "301", floor: 3, capacity: 3, occupants: 1, type: "triple", status: "available" },
  { id: "r8", number: "302", floor: 3, capacity: 1, occupants: 0, type: "single", status: "available" },
];

export const mockComplaints: Complaint[] = [
  { id: "c1", studentId: "s1", studentName: "Aarav Sharma", subject: "Water leakage", description: "Bathroom tap is leaking constantly.", status: "pending", createdAt: "2026-03-10", resolvedAt: null },
  { id: "c2", studentId: "s3", studentName: "Rohan Gupta", subject: "WiFi not working", description: "Internet connectivity is very poor in room 103.", status: "in-progress", createdAt: "2026-03-08", resolvedAt: null },
  { id: "c3", studentId: "s2", studentName: "Priya Patel", subject: "Broken window", description: "Window glass is cracked.", status: "resolved", createdAt: "2026-02-20", resolvedAt: "2026-02-25" },
];

export const mockFees: FeeRecord[] = [
  { id: "f1", studentId: "s1", studentName: "Aarav Sharma", amount: 60000, paidDate: null, dueDate: "2026-03-31", status: "pending" },
  { id: "f2", studentId: "s2", studentName: "Priya Patel", amount: 60000, paidDate: "2026-01-15", dueDate: "2026-03-31", status: "paid" },
  { id: "f3", studentId: "s3", studentName: "Rohan Gupta", amount: 55000, paidDate: null, dueDate: "2026-02-28", status: "overdue" },
  { id: "f4", studentId: "s4", studentName: "Sneha Reddy", amount: 60000, paidDate: null, dueDate: "2026-03-31", status: "pending" },
  { id: "f5", studentId: "s5", studentName: "Vikram Singh", amount: 60000, paidDate: "2026-02-01", dueDate: "2026-03-31", status: "paid" },
  { id: "f6", studentId: "s6", studentName: "Ananya Nair", amount: 50000, paidDate: null, dueDate: "2026-02-28", status: "overdue" },
];

export const mockAttendance: AttendanceRecord[] = [
  { id: "a1", studentId: "s1", studentName: "Aarav Sharma", date: "2026-03-13", status: "present" },
  { id: "a2", studentId: "s2", studentName: "Priya Patel", date: "2026-03-13", status: "present" },
  { id: "a3", studentId: "s3", studentName: "Rohan Gupta", date: "2026-03-13", status: "absent" },
  { id: "a4", studentId: "s5", studentName: "Vikram Singh", date: "2026-03-13", status: "present" },
];
