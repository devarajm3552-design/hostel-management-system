import { Outlet } from "react-router-dom";
import AppSidebar from "./AppSidebar";
import { Bell, User } from "lucide-react";

const AppLayout = () => {
  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <div className="ml-64">
        <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-6 bg-card border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Hostel Management System</h2>
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-md hover:bg-muted transition-colors">
              <Bell className="h-5 w-5 text-muted-foreground" />
            </button>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">Admin</span>
            </div>
          </div>
        </header>
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
