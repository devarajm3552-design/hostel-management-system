import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  variant?: "default" | "accent" | "warning" | "destructive" | "success";
}

const variantStyles = {
  default: "bg-card border-border",
  accent: "bg-accent/10 border-accent/20",
  warning: "bg-warning/10 border-warning/20",
  destructive: "bg-destructive/10 border-destructive/20",
  success: "bg-success/10 border-success/20",
};

const iconStyles = {
  default: "text-primary bg-primary/10",
  accent: "text-accent bg-accent/15",
  warning: "text-warning bg-warning/15",
  destructive: "text-destructive bg-destructive/15",
  success: "text-success bg-success/15",
};

const StatCard = ({ title, value, icon: Icon, trend, variant = "default" }: StatCardProps) => {
  return (
    <div className={`rounded-lg border p-5 ${variantStyles[variant]}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground font-medium">{title}</p>
          <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
          {trend && <p className="text-xs text-muted-foreground mt-1">{trend}</p>}
        </div>
        <div className={`p-3 rounded-lg ${iconStyles[variant]}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
};

export default StatCard;
