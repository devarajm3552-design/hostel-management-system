export interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  course: string;
  roomId: string | null;
  registeredAt: string;
  feesPaid: number;
  totalFees: number;
}

export interface Room {
  id: string;
  number: string;
  floor: number;
  capacity: number;
  occupants: number;
  type: "single" | "double" | "triple";
  status: "available" | "occupied" | "maintenance";
}

export interface Complaint {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  description: string;
  status: "pending" | "in-progress" | "resolved";
  createdAt: string;
  resolvedAt: string | null;
}

export interface FeeRecord {
  id: string;
  studentId: string;
  studentName: string;
  amount: number;
  paidDate: string | null;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  date: string;
  status: "present" | "absent";
}
